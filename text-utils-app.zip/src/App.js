import "./App.css";
import UtilsApp from "./components/UtilsApp";

function App() {
  return <UtilsApp />;
}

export default App;
