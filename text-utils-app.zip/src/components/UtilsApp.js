import { useState } from "react";
import "./UtilsApp.css";

import DisplayText from "./DisplayText";

const UtilsApp = () => {
  const [text, setText] = useState("");
  const [toggleMode, setToggleMode] = useState({
    color: "white",
    backgroundColor: "lightgreen",
  });
  const [isAlert, setAlert] = useState(false);
  const [message, setMessage] = useState("");
  const [alertMessage, setAlertMessage] = useState("");
  const [color, setColor] = useState("");

  const [darkMode, setDarkMode] = useState(false);

  setTimeout(() => {
    setAlert(false);
  }, 2000);

  const toggleModeOnOff = () => {
    if (!darkMode) {
      setToggleMode({
        color: "white",
        backgroundColor: "black",
      });
      setAlert(true);
      setColor("green");
      setMessage("Success");
      setAlertMessage("Entered Into Dark Mode");
      setDarkMode(true);
    } else if (darkMode) {
      setToggleMode({
        color: "white",
        backgroundColor: "lightgreen",
      });
      setAlert(true);
      setColor("green");
      setMessage("Success");
      setAlertMessage("Entered Into Light Mode");
      setDarkMode(false);
    }
  };

  const convertToUpperCase = () => {
    if (!text == "") {
      setText(text.toUpperCase());
      setColor("green");
      setAlert(true);
      setMessage("Success");
      setAlertMessage("Converted To Upper Case");
    } else {
      setAlert(true);
      setMessage("Danger");
      setColor("red");
      setAlertMessage("Entered Before This Operation");
    }
  };
  const convertToLowerCase = () => {
    if (!text == "") {
      setText(text.toLowerCase());
      setAlert(true);
      setColor("green");
      setMessage("Success");
      setAlertMessage("Converted To Lower Case");
    } else {
      setAlert(true);
      setColor("red");
      setMessage("Danger");
      setAlertMessage("Entered Before This Operation");
    }
  };
  const handleCopy = () => {
    if (!text == "") {
      const text = document.getElementById("textArea");
      text.select();
      navigator.clipboard.writeText(text.value);
      setAlert(true);
      setMessage("Success");
      setAlertMessage("Copied To Clipboard");
    } else {
      setAlert(true);
      setMessage("Danger");
      setAlertMessage("Entered Before This Operation");
    }
  };
  const textChanged = (event) => {
    setText(event.target.value);
  };
  const clearText = () => {
    if (!text == "") {
      setText("");
      setAlert(true);
      setMessage("Success");
      setAlertMessage("Cleared");
    } else {
      setAlert(true);
      setMessage("Danger");
      setAlertMessage("Entered Before This Operation");
    }
  };

  return (
    <div className="container" style={toggleMode}>
      <h1 style={toggleMode}>TEXT UTILS APP</h1>
      <DisplayText
        alert={isAlert}
        message={message}
        alertMessage={alertMessage}
        color={color}
      />
      <textarea
        placeholder="Start Typing Your Text Here..."
        value={text}
        id="textArea"
        cols="150"
        rows="30"
        onChange={textChanged}
      />
      <div className="btnContainer">
        <button onClick={convertToUpperCase}>Convert To UpperCase</button>
        <button onClick={convertToLowerCase}>Convert To LowerCase</button>
        <button onClick={handleCopy}>Copy Text To Clipboard</button>
        <button onClick={clearText}>Clear All The Text</button>
        <button onClick={toggleModeOnOff}>Toggle Dark Mode</button>
      </div>
    </div>
  );
};

export default UtilsApp;
