import React, { useState } from "react";

const DisplayText = ({ alert, message, alertMessage, color }) => {
  return (
    alert && (
      <div>
        <h2>
          <span style={{ color: color }}> {message}</span>, The text has been{" "}
          {alertMessage}.
        </h2>
      </div>
    )
  );
};

export default DisplayText;
